# Brightside English — Vercel Deployment

## 🚀 Deploy to Vercel (3 ways)

### Option 1: Drag & Drop (Easiest)
1. Go to → https://vercel.com/new
2. Click **"Deploy without a Git repository"** (or drag & drop this folder)
3. Your site is LIVE ✅

### Option 2: Vercel CLI
```bash
npm install -g vercel
vercel
```
Follow the prompts — done in 30 seconds.

### Option 3: GitHub → Vercel (Auto-deploy)
1. Push this folder to a GitHub repo
2. Go to https://vercel.com/new
3. Import your GitHub repo
4. Click Deploy ✅ — every push auto-deploys

## 📁 Project Structure
```
brightside-vercel/
├── public/
│   └── index.html   ← your landing page
└── vercel.json      ← Vercel config
```
